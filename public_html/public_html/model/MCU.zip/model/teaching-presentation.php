<?php
include ('../views/header.php'); 

?>

<br>


<iframe src="https://docs.google.com/presentation/d/12vZPHnl45IFNUUtshKzACLABMjmI_saC3GuKUvStIkI/embed?start=false&amp;loop=false&amp;delayms=3000" width="800" height="540" ></iframe>


<br>

<?php

include ('../views/footer.php'); 

?>
