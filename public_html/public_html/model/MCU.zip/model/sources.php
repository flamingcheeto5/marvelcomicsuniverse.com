<?php
include ('../views/header.php'); 

?>

<div class="h1">
<h1>Sources: </h1>
</div>

<a href="http://marvel.com"  style="color:white" target="_blank">Marvel Official Website</a>
<br><br>
<a href="http://marvel.wikia.com"  style="color:white" target="_blank">Marvel Wikia</a>
<br><br>
<a href="http://imdb.com"  style="color:white" target="_blank">Internet Movie Database</a>
<br><br>
<a href="http://youtube.com" style="color:white" target="_blank">Youtube</a>




<?php

include ('../views/footer.php'); 

?>