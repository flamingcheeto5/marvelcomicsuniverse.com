<?php?>
<br><br>

<title>Sign-Up</title>
<div id="movie-trailer">
<fieldset style="width:30%"><legend style="color:white">Registration Form</legend>
<table border="0">
<tr>
<form method="POST" action="connectivity-sign-up.php">
<td style="color:white">Full Name</td><td> <input type="text" name="name"></td>
</tr>
<tr>
<td style="color:white">Email</td><td> <input type="text" name="email"></td>
</tr>
<tr>
<td style="color:white">UserName</td><td> <input type="text" name="user"></td>
</tr>
<tr>
<td style="color:white">Password</td><td> <input type="password" name="pass"></td>
</tr>
<tr>
<td style="color:white">Confirm Password </td><td><input type="password" name="cpass"></td>
</tr>
<tr>
<td><input id="button" type="submit" name="submit" value="Sign-Up"></td>
</tr>
</form>
</table>
</fieldset>
<br><br>
</div>
