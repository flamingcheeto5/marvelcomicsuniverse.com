<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"For Steve Rogers, awakening after decades of suspended animation involves more than catching up on pop culture; it also means that this old school 
idealist must face a world of subtler threats and difficult moral complexities. That comes clear when Director Nick Fury is killed by the mysterious 
assassin, the Winter Soldier, but not before warning Rogers that SHIELD has been subverted by its enemies. When Rogers acts on Fury's warning to trust 
no one there, he is branded as a traitor by the organization. Now a fugitive, Captain America must get to the bottom of this deadly mystery with the 
help of the Black Widow and his new friend, The Falcon. However, the battle will be costly for the Sentinel of Liberty, with Rogers finding enemies 
where he least expects them while learning that the Winter Soldier looks disturbingly familiar."
</p>

<a style="color:#ABABAB" target="_blank" href='http://www.imdb.com/search/title?plot_author=halo1k%20view=simple%20sort=alpha%20ref_=ttpl_pl_3'>
-  halo1k
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/rXKhVQ9Qh1E" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>