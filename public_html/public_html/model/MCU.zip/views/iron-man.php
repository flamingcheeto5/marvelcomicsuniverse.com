<?php
include ('header.php'); 

?>

<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"Tony Stark is the complete playboy who also happens to be an engineering genius. While in Afghanistan demonstrating a new missile, he's captured and wounded. 
 His captors want him to assemble a missile for them but instead he creates an armored suit and a means to prevent his death from the shrapnel left in his chest 
 by the attack. He uses the armored suit to escape. Back in the U.S. he announces his company will cease making weapons and he begins work on an updated armored 
 suit only to find that Obadiah Stane, his second in command at Stark industries has been selling Stark weapons to the insurgents. 
 He uses his new suit to return to Afghanistan to destroy the arms and then to stop Stane from misusing his research."
</p>
<a style="color:#6E6E6E" target="_blank" href="http://www.imdb.com/name/nm0900917/">
-  John Vogel
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/bK_Y5LjSJ-Y" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
