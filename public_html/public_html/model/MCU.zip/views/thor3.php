<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#FF8C00">Plot Summary:</h2>
<p style="color:#A9A9A9">
The Plot details have not been released for this movie. Please enjoy this YouTube video I have found about potential plot ideas. Enjoy!
</p>
<p style="color:#A9A9A9">
- David Banks
</p>

<a href="http://moviepilot.com/posts/2014/04/14/thor-3-spoilers-ragnarok-loki-and-the-fall-of-asgard-1332386?lt_source=external,manual" 
target="_blank" style="color:#A9A9A9">Movie Pilot Thor 3 Rumors</a>

</div>

<div id="movie-trailer">
<br>
<iframe width="383" height="205" src="//www.youtube.com/embed/xXZgN1uCkrQ"></iframe>
<br><br>
</div>

<?php

include ('footer.php'); 

?>