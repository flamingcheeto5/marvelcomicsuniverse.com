<?php
include ('header.php'); 

?>

<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"A cure is in reach for the world's most primal force of fury: THE INCREDIBLE HULK. We find scientist Bruce Banner, living in shadows, scouring the planet for an 
antidote. But the warmongers who dream of abusing his powers won't leave him alone, nor will his need to be with the only woman he has ever loved, Betty Ross. 
Upon returning to civilization, our brilliant doctor is ruthlessly pursued by The Abomination -- a nightmarish beast of pure adrenaline and aggression whose powers 
match The Hulk's own. A fight of comic-book proportions ensues as Banner must call upon the hero within to rescue New York City from total destruction. 
One scientist must make an agonizing final choice -- accept a peaceful life as Bruce Banner or the creature he could permanently become: THE INCREDIBLE HULK."

</p>
<a style="color:#6E6E6E" target="_blank" href='http://www.imdb.com/search/title?plot_author=Babak+A.%20view=simple%20sort=alpha%20'>
-  Babak A. 
</a>
<br><br>
</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/7Z-tsPXi_qs" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
