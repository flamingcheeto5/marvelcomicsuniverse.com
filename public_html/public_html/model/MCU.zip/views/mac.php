<?php
include ('header.php'); 


?>
<div id="section">
<h2 style="color:red">Plot Summary:</h2>
<p style="color:white">
"Peggy Carter becomes a S.H.I.E.L.D. agent during WW2 after her boyfriend, Steve Rogers (Captain America) is feared dead in an explosion. "
</p>
<a style="color:white" target="_blank" href=' http://www.imdb.com/search/title?plot_author=ABC%20view=simple%20sort=alpha%20ref_=ttpl_pl_1'>
- ABC
</a>
<br>
<br>
</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/fyNUbAHyr9E" allowfullscreen></iframe>
<br><br><br>
</div>

<?php

include ('footer.php'); 

?>