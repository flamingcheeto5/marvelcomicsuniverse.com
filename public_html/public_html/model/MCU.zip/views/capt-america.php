<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"It is 1942, America has entered World War II, and sickly but determined Steve Rogers is frustrated at being rejected yet again for military service. 
Everything changes when Dr. Erskine recruits him for the secret Project Rebirth. Proving his extraordinary courage, wits and conscience, Rogers undergoes 
the experiment and his weak body is suddenly enhanced into the maximum human potential. When Dr. Erskine is then immediately assassinated by an agent of 
Nazi Germany's secret HYDRA research department (headed by Johann Schmidt, a.k.a. the Red Skull), Rogers is left as a unique man who is initially misused 
as a propaganda mascot; however, when his comrades need him, Rogers goes on a successful adventure that truly makes him Captain America, and his war against 
Schmidt begins. "
</p>
<a style="color:#6E6E6E" target="_blank" href=' http://www.imdb.com/title/tt2364582/plotsummary?ref_=tt_stry_pl'>
- Kenneth Chisholm
</a>
<br><br>
</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/W4DlMggBPvc" allowfullscreen></iframe>
<br>
</div>



<?php

include ('footer.php'); 

?>
