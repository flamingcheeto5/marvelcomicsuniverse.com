<?php
include ('header.php'); 

?>

<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"The reckless Thor (Chris Hemsworth) son of Odin (Anthony Hopkins), challenges his brother's claim to the throne of Asgard. To teach him humility , 
Odin casts the young warrior down to Earth to live among humans. Robbed of his powers, Thor falls in love with a scientist Jane Foster (Natalie Portman). 
While Thor's brother; Loki usurps the throne of Asgard for evil gain and plans revenge, Thor's love for Jane and his lessons of humility turn him into 
the true hero and legendary and immortal warrior-defender of the peoples of the Earth saving them from destruction. "
</p>
<a style="color:#6E6E6E" target="_blank" href='http://www.imdb.com/search/title?plot_author=PJT%20view=simple%20sort=alpha%20ref_=ttpl_pl_2'>
- PJT 
</a>
<br><br>
</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/JOddp-nlNvQ" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
