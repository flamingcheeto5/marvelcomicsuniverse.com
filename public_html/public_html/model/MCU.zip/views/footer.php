<?php

?>
	<footer>
        <p>
            <a href="../model/teaching-presentation.php" style="color:white">Teaching Presentation</a>&nbsp;&nbsp;
            <a href="../model/site-plan.php" style="color:white">Site Plan</a>&nbsp;&nbsp;
			<a href="../model/sources.php" style="color:white">Sources</a>&nbsp;&nbsp;
            <a href="../model/source-code.php" style="color:white">Source Code</a>&nbsp;&nbsp;
			<a href="../admin/login.php" style="color:white">Admin Console</a>
        </p>
        <p style="color:white">
			 BYU-I CIT 336<br>
               David Banks    
        </p>
		
<br>
    </footer>

  </body>
</html>