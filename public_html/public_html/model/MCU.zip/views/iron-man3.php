<?php
include ('header.php'); 

?>

<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"The events of Loki's attack on New York City has left Tony Stark a completely changed man. Now saddled with a severe case of insomnia and post traumatic 
stress disorder, Tony spends his sleepless nights the only way he knows how - coming up with new prototypes for the Iron Man suit. But now new events require 
that Tony suit up again. A villainous mad man known only as the Mandarin has staged a horrible attack on the Chinese Theater in Los Angeles, and is coming for 
Tony. An angry Tony wants to confront the Mandarin face to face, who proceeds to stage an attack on Tony's Malibu mansion and leaves him with absolutely nothing
 - no Pepper, no toys except for a defunct Iron Man prototype called the MK42, and he's stranded in the middle of Tennessee. Tony believes the attack on the Chinese 
 Theater and an attack on a small town in Tennessee are related. As he puts the pieces together and tries to get the MK42 working, he discovers far more sinister 
 forces at work greater than the Mandarin himself. But how does an event from Tony's past fit in with the events of the present? "
</p>
<a style="color:#ABABAB" target="_blank" href='http://www.imdb.com/search/title?plot_author=halo1k%20view=simple%20sort=alpha%20ref_=ttpl_pl_3'>
-  halo1k
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/YLorLVa95Xo" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
