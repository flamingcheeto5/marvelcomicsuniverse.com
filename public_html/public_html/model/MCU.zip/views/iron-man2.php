<?php
include ('header.php'); 

?>

<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"Now that Tony Stark has revealed to the world that he is Iron Man, the entire world is now eager to get their hands on his hot technology - whether it's the 
United States government, weapons contractors, or someone else. That someone else happens to be Ivan Vanko - the son of now deceased Anton Vanko, Howard Stark's 
former partner. Stark had Vanko banished to Russia for conspiring to commit treason against the US, and now Ivan wants revenge against Tony - and he's willing 
to get it at any cost. But after being humiliated in front of the Senate Armed Forces Committee, rival weapons contractor Justin Hammer sees Ivan as the key to 
upping his status against Stark Enterprises after an attack on the Monaco 500. But an ailing Tony has to figure out a way to save himself, get Vanko, and get Hammer 
before the government shows up and takes his beloved suits away. And can he figure out what a mysterious figure named Nick Fury wants with him?"
</p>
<a style="color:#6E6E6E" target="_blank" href='http://www.imdb.com/search/title?plot_author=halo1k%20view=simple%20sort=alpha%20ref_=ttpl_pl_2'>
- halo1k  
</a>
<br><br>
</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/FNQowwwwYa0" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
