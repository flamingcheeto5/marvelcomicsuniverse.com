<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#FF8C00">Plot Summary:</h2>
<p style="color:#A9A9A9">
The Plot details have not been released for this movie. Please enjoy this YouTube video I have found about potential plot ideas. Enjoy!
</p>
<p style="color:#A9A9A9">
- David Banks
</p>

<br><br>

</div>

<div id="movie-trailer">
<br>
<iframe width="383" height="205" src="//www.youtube.com/embed/4lDfU3BmwPY" allowfullscreen></iframe>
<br><br>
</div>

<?php

include ('footer.php'); 

?>