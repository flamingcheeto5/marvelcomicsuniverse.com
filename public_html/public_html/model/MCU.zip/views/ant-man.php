<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"Armed with a super-suit with the astonishing ability to shrink in scale but increase in strength, con-man Scott Lang must embrace his inner 
hero and help his mentor, Dr. Hank Pym, plan and pull off a heist that will save the world."
</p>
<a style="color:#ABABAB" target="_blank" href='http://www.imdb.com/search/title?plot_author=Marvel.com%20view=simple%20sort=alpha%20ref_=ttpl_pl_2'>
- Marvel.com
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/moLhCE7qVpE?list=UUQMbqH7xJu5aTAPQ9y_U7WQ" allowfullscreen></iframe>
<br><br>
</div>
<?php

include ('footer.php'); 

?>