<?php
include ('header.php'); 

?>
<div class="origins-h1">
<h1 style="color:yellow">Dr. Strange Origins:</h1>
</div>
<br>
<br>
<div class="origins-videos">
<iframe width="560" height="315" src="//www.youtube.com/embed/Eyk5QaroPBQ" allowfullscreen></iframe>
<br>
</div>


<?php

include ('footer.php'); 

?>