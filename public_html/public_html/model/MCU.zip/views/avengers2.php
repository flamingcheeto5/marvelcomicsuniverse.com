<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"When Tony Stark tries to jumpstart a dormant peacekeeping program, things go awry and Earth's Mightiest Heroes, including Iron Man, 
Captain America, Thor, The Incredible Hulk, Black Widow and Hawkeye, are put to the ultimate test as the fate of the planet hangs in 
the balance. As the villainous Ultron emerges, it is up to The Avengers to stop him from enacting his terrible plans, and soon uneasy 
alliances and unexpected action pave the way for a global adventure. "
</p>
<a style="color:#ABABAB" target="_blank" href=' http://www.imdb.com/search/title?plot_author=Marvel+Studios%20view=simple%20sort=alpha%20ref_=ttpl_pl_1'>
- Marvel Studios
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/fk24PuBUUkQ"></iframe>

<br><br>

<iframe width="395" height="205" src="//www.youtube.com/embed/rQE2P3drS_g?list=UUQMbqH7xJu5aTAPQ9y_U7WQ"></iframe>
<br><br>
</div>



<?php

include ('footer.php'); 

?>