<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"In 1988, on Earth, the boy Peter Quill is abducted by a spacecraft after losing his mother. In 2014, Peter Quill, a.k.a. Star Lord, is a ravager searching
 a valuable orb on the surface of the dead planet Morag. When Peter finds the orb, he is hunted down by the Kree warship The Dark Aster of the powerful Ronan 
 the Accuser but he flees. Peter also double crosses his partner Yondu Udonta that puts a reward on him. Peter Quill arrives on the Xandar city Nova Empire and 
 is chased by Ronan's warrior Gamora and by the bounty hunters Rocket and The Groot. They are arrested by the police officer Corpsman Dey and his men and sent 
 to the prison The Kyln, where they befriend the strong Drax. Soon they learn that Gamora wants to betray Ronan and sell the orb to a dealer for a huge amount 
 while Drax wants to kill Ronan, who killed his wife and daughter. They plot a plan to escape from The Kyln to sell the orb and split the money. But soon they 
 also learn that the orb keeps the infinity stone that gives immensurable destructive power to the owner. They self-proclaim Guardians of the Galaxy and decide 
 to deliver the orb to the leader Nova Prime to keep it safe from Ronan. But they are hunted down by Ronan and his right-arm Nebula that want to destroy Xandar 
 and also by Yondu Udonta and the Ravagers that want to sell the infinity stone to make lots of money. Who will keep the powerful orb? "
</p>
<a style="color:#ABABAB" target="_blank" href='http://www.imdb.com/search/title?plot_author=Claudio+Carvalho%2C+Rio+de+Janeiro%2C+Brazil%20view=simple%20sort=alpha%20ref_=ttpl_pl_3'>
-  Claudio Carvalho
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/crIaEzXgqto" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>