<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="David Banks">
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
        <title>Marvel Comics Universe Fan Page!</title>
        <link rel="stylesheet" type="text/css" href="../css/main.css" />
    </head>    


         <div id="header">
        <div id="banner">
        </div>
        
        <nav>
            <ul>
                                <li>
                    <a href='../index.html' style="color:white">Home</a>
                </li>
                                <li>
                    <a href='../views/movies.php' style="color:white">Cinematic Universe</a>
                </li>
                                <li>
                    <a href='../views/origin-stories.php' style="color:white">Origin Stories</a>
                </li>
                                <li>
                    <a href='../model/contact.php' style="color:white">Contact</a>
                </li>
                                <li>
                    <a href='../model/login.php' style="color:white">Log In</a>
                </li>
			</ul>
		</nav>
      </div>
