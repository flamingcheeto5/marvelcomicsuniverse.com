<?php
include ('header.php');
?>

<div class="origins-h1">
<h1 style="color:yellow">Civil War Origins:</h1>
</div>
<br>
<br>

<div class="origins-videos">
<iframe width="560" height="315" src="//www.youtube.com/embed/pPPZGZE14pA" allowfullscreen></iframe>
<br>
</div>



<div class="origins-h1">
<h1 style="color:yellow">For those of you who are brave, here is a VERY in-depth look at Marvel's Civil War:</h1>
<p style="color:yellow">(it's a playlist of 22 videos)</p>
</div>
<br>
<br>

<div class="origins-videos">
<iframe width="560" height="315" src="//www.youtube.com/embed/m9JVJJilGYY?list=PL9sO35KZL50ympu-QGhc9IbUVTeXfM851" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>
