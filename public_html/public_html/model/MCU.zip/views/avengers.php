<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:blue">Plot Summary:</h2>
<p style="color:#6E6E6E">
"S.H.I.E.L.D. has located the mysterious Tesseract device and the Army's super soldier Captain America. The Tesseract is actually a gateway to 
an entirely new world called Asguard. A mysterious being known as Loki arrives on earth and immediately assumes that he can rule all human beings. 
But that irks S.H.I.E.L.D. directory Nick Fury the wrong way. As Loki escapes with the Tesseract, Nick Fury believes this is an act of war against 
Earth. His only hope is to assemble an actual team of super heroes. Dr. Bruce Banner, who turns into an enormous green rage monster known as the Hulk. 
Tony Stark and his venerable Iron Man armor. Captain America, the Stark Enterprises created super soldier. Thor, the god of thunder, protector of Earth 
and his home planet of Asguard, and Loki's brother. Master assassins Hawkeye and Natasha Romanoff. Together they will become a team to take on an attack 
that will call them to become the greatest of all time. "
</p>
<a style="color:#6E6E6E" target="_blank" href='http://www.imdb.com/search/title?plot_author=halo1k%20view=simple%20sort=alpha%20ref_=ttpl_pl_3'>
-  halo1k
</a>
<br><br>
</div>
<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/eOrNdBpGMv8" allowfullscreen></iframe>
</div>


<?php

include ('footer.php'); 

?>