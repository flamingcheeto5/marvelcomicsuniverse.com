<?php
include ('header.php'); 

?>
<div class="origins-h1">
<h1 style="color:yellow">Thor Origins:</h1>
</div>
<br>
<br>

<div class="origins-videos">
<iframe width="560" height="315" src="//www.youtube.com/embed/XKTwrPnpwfY" allowfullscreen></iframe>
<br>
</div>



<?php

include ('footer.php'); 

?>