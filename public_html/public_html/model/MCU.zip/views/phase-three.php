<?php
include ('header.php'); 

?>
<br>
<div id="titlepic">
<br>
<img src="../images/phase-three.jpg" alt="Phase Three" id="p3headerpic"/>
</div>	

<br><br><br><br>

	<div id="p3timeline">
	<a href="phase-three-spec.php"><img src="../images/phase-three1.jpg" alt="Phase Three"></a>
	</div>
	
	<br><br>
	
	<div class="movie-poster-p3">
	<a href="capt-america3.php"><img src="../images/captain-america3.jpg" alt="Captain America 3"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="drstrange.php"><img src="../images/drstrange.jpg" alt="Doctor Strange"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="guardians2.php"><img src="../images/guardians2.jpg" alt="Guardians of the Galaxy 2"></a>
	</div>

<br><br>
	
	<div class="movie-poster-p3">
	<a href="thor3.php"><img src="../images/thor3.jpg" alt="Thor 3"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="blackpanther.php"><img src="../images/blackpanther.jpg" alt="Black Panther"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="avengers-iw-1.php"><img src="../images/avengers-iw-1.jpg" alt="Avengers IW 1"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="captain-marvel.php"><img src="../images/captain-marvel.jpg" alt="Captain Marvel"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="inhumans.php"><img src="../images/inhumans.jpg" alt="Inhumans"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p3">
	<a href="avengers-iw-2.php"><img src="../images/avengers-iw-2.jpg" alt="Avengers IW 2"></a>
	</div>

<br><br>
	
<?php

include ('footer.php'); 

?>