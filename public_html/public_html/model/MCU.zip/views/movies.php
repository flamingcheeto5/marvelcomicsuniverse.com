<?php
include ('header.php'); 
?>

<br><br>

<div class="mainmarvel">
	<a href="phase-one.php">
<figure>
		<img src="../images/phase-one.jpg" alt="Phase One" id="p1headerpic"/>
	</figure>
	</a>

<br>

	</div>

<div class="mainmarvel">
	<a href="phase-two.php">
<figure>
		<img src="../images/phase-two.jpg" alt="Phase Two" id="p2headerpic" />
	</figure>	
	</a>
	
<br>

	<a href="phase-three.php">
<figure>
		<img src="../images/phase-three.jpg" alt="Phase Three"  id="p3headerpic"/>
	</figure>	
	</a>

<br>

	<a href="maos.php">
<figure>
		<img src="../images/maos.jpg" alt="Marvel Agents of Shield" id="mcutv" />
	</figure>
	</a>

<br>
	
	<a href="mac.php">
<figure>
		<img src="../images/mac.jpg" alt="Marvel Agent Carter"  id="mcutv1"/>
	</figure>	
	</a>

<br>

</div>
<?php

include ('footer.php'); 

?>
