<?php
include ('header.php'); 

?>
<br>
<div id="titlepic">
<br>
<img src="../images/phase-two.jpg" alt="Phase Two" id="p2headerpic" />
</div>	

<br><br><br><br>

	<div class="movie-poster-p2">
	<a href="iron-man3.php"><img src="../images/iron-man3.jpg" alt="Iron Man 3"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p2">
	<a href="thor2.php"><img src="../images/thor2.jpg" alt="Thor 2"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p2">
	<a href="capt-america2.php"><img src="../images/captain-america2.jpg" alt="Captain America 2"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p2">
	<a href="guardians.php"><img src="../images/guardians.jpg" alt="Guardians of the Galaxy"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p2">
	<a href="avengers2.php"><img src="../images/avengers2.jpg" alt="Avengers 2"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p2">
	<a href="ant-man.php"><img src="../images/ant-man.jpg" alt="Ant Man"></a>
	</div>

<br><br>
	
<?php

include ('footer.php'); 

?>
