<?php
include ('header.php'); 

?>
<br>
<div id="titlepic">
<br>
<img src="../images/phase-one.jpg" alt="Phase One" id="p1headerpic"/>
</div>	

<br><br><br><br>

	<div class="movie-poster-p1">
	<a href="iron-man.php"><img src="../images/iron-man-08.jpg" alt="Iron Man"></a>
	</div>

<br><br>
	
	<div class="movie-poster-p1">
	<a href="ihulk.php"><img src="../images/ihulk-08.jpg" alt="Incredible Hulk"></a>
	</div>

<br><br>
	
	<div class="movie-poster-p1">
	<a href="iron-man2.php"><img src="../images/iron-man2.jpg" alt="Iron Man 2"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p1">
	<a href="thor.php"><img src="../images/thor-11.jpg" alt="Thor"></a>
	</div>
	
<br><br>
	
	<div class="movie-poster-p1">
	<a href="capt-america.php"><img src="../images/capt-america-11.jpg" alt="Captain America"></a>
	</div>

<br><br>
	
	<div class="movie-poster-p1">
	<a href="avengers.php"><img src="../images/avengers.jpg" alt="Avengers"></a>
	</div>

<br><br>
	
<?php

include ('footer.php'); 

?>



