<?php
include ('header.php'); 

?>

<br>
<div id="section">
<h2 style="color:red">Plot Summary:</h2>
<p style="color:white">
"After the Battle of New York, the world has changed. It now knows not only about the Avengers, but also the powerful menaces that require those superheroes and more to face them. In response, Phil Coulson of the Strategic Homeland Intervention, Enforcement and Logistics Division assembles an elite covert team to find and deal with these threats wherever they are found. 
	With a world rapidly becoming more bizarre and dangerous than ever before as the supervillains arise, these agents of S.H.I.E.L.D. are ready to take them on."
</p>
<a style="color:white" target="_blank" href=' http://www.imdb.com/title/tt2364582/plotsummary?ref_=tt_stry_pl'>
- Kenneth Chisholm
</a>
<br>
<br>
<img src="../images/shield-hydra.jpg" alt="Shield - Hydra"/>
</div>

<br><br><br>

<div id="movie-trailer">
<iframe width="383" height="205" src="//www.youtube.com/embed/T3T-evQZiQo" allowfullscreen></iframe>

<br><br>
<br><br>

<iframe width="383" height="205" src="//www.youtube.com/embed/PahISq6DKws" allowfullscreen></iframe>
<br><br>
</div>

<br>


	<a href="phase-two.php"></a>
<figure>
		
	</figure>
	<br>

<?php

include ('footer.php'); 

?>