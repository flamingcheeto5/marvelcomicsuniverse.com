<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#FF8C00">Plot Summary:</h2>
<p style="color:#A9A9A9">
Below are some announcement links:
</p>


<p>
<a style="color:#A9A9A9" target="_blank" href='http://marvel.com/news/movies/23547/marvel_studios_announces_full_phase_3_slate_at_special_event'>
Marvel - Marvel Studios Announces Full Phase 3 Slate at Special Event</a>
</p>

<br>

<p>
<a style="color:#A9A9A9" target="_blank" href='http://moviepilot.com/posts/2014/11/25/captain-america-civil-war-black-panther-more-marvel-s-phase-3-lineup-2461168?lt_source=external,manual'>
Movie Piolot - Captain America: Civil War, Black Panther, & More: Marvel's Phase 3 Lineup</a>
</p>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/-E4i_dV7N5I" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>