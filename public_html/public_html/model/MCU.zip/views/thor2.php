<?php
include ('header.php'); 

?>
<div id="section">
<h2 style="color:#8F0000">Plot Summary:</h2>
<p style="color:#ABABAB">
"There are nine realms of Asgard and once every 5,000 years they align. Earth happens to be one of these realms. These realms create portals between 
the worlds during the alignment which is called "Convergence". On Earth, in London, Jane Foster believes she and her crew have discovered one such portal. 
Foster, while investigating the phenomenon, is transported to another realm and comes in contact with a substance called Aether. Upon coming into contact 
with the substance, it draws Thor from Asgard back to Earth. Thor takes Jane to Asgard to be cured from the Aether. Unfortunately in doing so it draws more 
than just Jane to that world. Another being called Malekith wants to use the Aether to destroy Asgard. Devising a plan with his brother - the war criminal 
Loki, Thor heads to "The Dark World" to destroy the Aether and save Asgard. But can Loki be trusted? "
</p>
<a style="color:#ABABAB" target="_blank" href='http://www.imdb.com/search/title?plot_author=halo1k%20view=simple%20sort=alpha%20ref_=ttpl_pl_3'>
-  halo1k
</a>

<br><br>

</div>

<div id="movie-trailer">
<br><br>
<iframe width="383" height="205" src="//www.youtube.com/embed/tvKjS2s1v0k" allowfullscreen></iframe>
</div>

<?php

include ('footer.php'); 

?>