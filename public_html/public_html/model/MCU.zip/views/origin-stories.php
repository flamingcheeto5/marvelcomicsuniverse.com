<?php
include ('header.php'); 
?>

<br>

<div id="titlepic">
		<img src="../images/marvel-classic-logo.jpg" alt="Origins - Main" id="origins-main"/>
</div>

<br><br><br><br><br>
<br><br><br><br><br><br>

	<div class="origins">
	<a href="civil-war.php"><img src="../images/civil-war.jpg" alt="Civil War - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="iron-man-origins.php"><img src="../images/tos-391.jpg" alt="Iron Man - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="ihulk-origins.php"><img src="../images/hulk-11.jpg" alt="Incredible Hulk - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="thor-origins.php"><img src="../images/jim-831.jpg"  alt="Thor - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="cap-america-origins.php"><img src="../images/cap-origin.jpg"  alt="Captain America - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="avengers-origins.php"><img src="../images/avengers-12.jpg"  alt="Avengers - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="guardians-origins.php"><img src="../images/msh-18.jpg"  alt="Guardians of the Galaxy - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="ant-man-origins.php"><img src="../images/tta-271.jpg"  alt="Ant Man - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="drstrange-origins.php"><img src="../images/strange-tales-1102.jpg"  alt="Dr. Strange - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="blackpanther-origins.php"><img src="../images/bp-origins.jpg"  alt="Black Panther - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="cap-marvel-origins.php"><img src="../images/captain-marvel-origins.jpg"  alt="Captain Marvel - Origins"></a>
	</div>
	
<br><br>
	
	<div class="origins">
	<a href="inhumans-origins.php"><img src="../images/inhumans-origins.jpg"  alt="Inhumans - Origins"></a>
	</div>

<br><br>
	
<?php

include ('footer.php'); 

?>
